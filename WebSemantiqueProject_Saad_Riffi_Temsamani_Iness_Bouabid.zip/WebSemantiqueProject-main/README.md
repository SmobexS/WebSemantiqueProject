# WebSemantiqueProject

Notes:
* The collect part of the application takes a lot of time to be executed (between 1 to 2 hours)
* If the data store is empy, the collect function will run until it finishes and then you can use the describe function and make searches
* If you want to run the application without waiting 2 hours for the data to be collected use the "combined_rdf.ttl" file to upload the data to the data store

* To start the application run the Main.py file
